// Chrisitan Sebo
// AIRGEAD BANKING
// 06/01/2024

#include <iostream>
#include <iomanip>
#include <vector>

// I'm creating a class to store the results for each year
class InvestmentRecord {
public:
    int year;
    double balance;
    double interestEarned;

    InvestmentRecord(int y, double b, double i) : year(y), balance(b), interestEarned(i) {}
};

// This class will handle all the calculations and store the results
class InvestmentCalculator {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;
    std::vector<InvestmentRecord> resultsNoDeposit;
    std::vector<InvestmentRecord> resultsWithDeposit;

public:
    // Constructor to initialize the calculator with user input values
    InvestmentCalculator(double initial, double monthly, double annualRate, int years) :
        initialInvestment(initial), monthlyDeposit(monthly), annualInterestRate(annualRate), numberOfYears(years) {}

    // This function calculates the balance and interest without monthly deposits
    void calculateWithoutMonthlyDeposits() {
        double currentBalance = initialInvestment;
        for (int year = 1; year <= numberOfYears; ++year) {
            double interestEarned = currentBalance * (annualInterestRate / 100);
            currentBalance += interestEarned;
            resultsNoDeposit.push_back(InvestmentRecord(year, currentBalance, interestEarned));
        }
    }

    // This function calculates the balance and interest with monthly deposits
    void calculateWithMonthlyDeposits() {
        double currentBalance = initialInvestment;
        for (int year = 1; year <= numberOfYears; ++year) {
            double totalInterestEarned = 0.0;
            for (int month = 1; month <= 12; ++month) {
                double monthlyInterestRate = (annualInterestRate / 100) / 12;
                currentBalance += monthlyDeposit;
                double interestEarned = currentBalance * monthlyInterestRate;
                currentBalance += interestEarned;
                totalInterestEarned += interestEarned;
            }
            resultsWithDeposit.push_back(InvestmentRecord(year, currentBalance, totalInterestEarned));
        }
    }

    // This function displays the results to the user
    void displayResults() const {
        std::cout << "Year | Balance without Deposits | Interest Earned without Deposits\n";
        for (const auto& record : resultsNoDeposit) {
            std::cout << std::setw(4) << record.year << " | "
                << std::setw(24) << std::fixed << std::setprecision(2) << record.balance << " | "
                << std::setw(28) << record.interestEarned << "\n";
        }

        std::cout << "\nYear | Balance with Deposits | Interest Earned with Deposits\n";
        for (const auto& record : resultsWithDeposit) {
            std::cout << std::setw(4) << record.year << " | "
                << std::setw(21) << std::fixed << std::setprecision(2) << record.balance << " | "
                << std::setw(26) << record.interestEarned << "\n";
        }
    }
};

int main() {
    // Step 1: Initialize and Display Welcome Message
    std::cout << "Welcome to the Airgead Banking Investment Calculator\n";

    // Step 2: User Input
    double initialInvestment;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;

    // Asking the user for the initial investment amount
    std::cout << "Enter initial investment amount: ";
    std::cin >> initialInvestment;
    // Asking the user for the monthly deposit amount
    std::cout << "Enter monthly deposit: ";
    std::cin >> monthlyDeposit;
    // Asking the user for the annual interest rate
    std::cout << "Enter annual interest rate (in %): ";
    std::cin >> annualInterestRate;
    // Asking the user for the number of years to invest
    std::cout << "Enter number of years to invest: ";
    std::cin >> numberOfYears;

    // Step 3 & 4: Calculations
    // Creating an instance of InvestmentCalculator with the user's input
    InvestmentCalculator calculator(initialInvestment, monthlyDeposit, annualInterestRate, numberOfYears);
    // Calculating the investment growth without monthly deposits
    calculator.calculateWithoutMonthlyDeposits();
    // Calculating the investment growth with monthly deposits
    calculator.calculateWithMonthlyDeposits();

    // Step 5: Display Results
    // Displaying the results to the user
    calculator.displayResults();

    return 0;
}
